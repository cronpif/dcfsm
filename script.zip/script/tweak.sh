#!/system/bin/sh
#Thank to ArjunrambZ
echo [*]Network Tweaking....
setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.umts 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.gprs 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.edge 4096,87380,256960,4096,16384,256960
echo "0" > /proc/sys/net/ipv4/tcp_timestamps;
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse;
echo "1" > /proc/sys/net/ipv4/tcp_sack;
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle;
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling;
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout;
echo "404480" > /proc/sys/net/core/wmem_max;
echo "404480" > /proc/sys/net/core/rmem_max;
echo "256960" > /proc/sys/net/core/rmem_default;
echo "256960" > /proc/sys/net/core/wmem_default;
echo "4096,16384,404480" > /proc/sys/net/ipv4/tcp_wmem;
echo "4096,87380,404480" > /proc/sys/net/ipv4/tcp_rmem;
echo [*]Tweaking RAM....
TDTADJ=/sys/module/lowmemorykiller/parameters/adj
    if [ -e "TDTADJ" ]; then
	    busybox chmod -f 644 "$TDTADJ"
		busybox echo "0,1,3,5,7,15" >> "$TDTADJ"
		busybox echo "$TDTADJ -> `busybox cat $TDTADJ`" >> "$TDTCAT"
	fi

TDTF=/sys/module/lowmemorykiller/parameters/lmk_fast_run
    if [ -e "$TDTF" ]; then
        busybox chmod -f 644 "$TDTF"
        busybox echo "1" >> "$TDTF"
        busybox echo "$TDTF -> `busybox cat $TDTF`" >> "$TDTCAT"
     fi
	 
#minfree

mem=`free|grep Mem | awk '{print $2}'`;

if [ "$mem" -lt 512000 ];then
    echo "1408,2816,3755,7040,9387,12288" > /sys/module/lowmemorykiller/parameters/minfree;	
elif [ "$mem" -lt 1024000 ];then
	echo "2560,4096,6144,12288,14336,18432" > /sys/module/lowmemorykiller/parameters/minfree;
else 
	echo "3755,6144,9387,14336,17284,21240" > /sys/module/lowmemorykiller/parameters/minfree;
fi;

TDTPC=/sys/module/lowmemorykiller/parameters/cost
    if [ -e "$TDTPC" ]; then
        busybox chmod -f 644 "$TDTPC"
        busybox echo "1024" >> "$TDTPC"
        busybox echo "$TDTPC -> `busybox cat $TDTPC`" >> "$TDTCAT"
    fi

TDTDB=/sys/module/lowmemorykiller/parameters/debug_level
    if [ -e "$TDTDB" ]; then
        busybox chmod -f 644 "$TDTDB"
        busybox echo "0" >> "$TDTDB"
        busybox echo "$TDTDB -> `busybox cat $TDTDB`" >> "$TDTCAT" 
    fi

TDTDA=/sys/module/lowmemorykiller/parameters/debug_adj
    if [ -e "$TDTDA" ]; then
        busybox chmod -f 644 "$TDTDA"
        busybox echo "0" >> "$TDTDA"
        busybox echo "$TDTDA -> `busybox cat $TDTDA`" >> "$TDTCAT" 
    fi
echo [*]Tweaking Kernel......
busybox sleep 2

chown 0.0 /sys/kernel/mm/ksm/pages_to_scan;
chmod 664 /sys/kernel/mm/ksm/pages_to_scan;
chown 0.0 /sys/kernel/mm/ksm/sleep_millisecs;
chmod 664 /sys/kernel/mm/ksm/sleep_millisecs;
chown 0.0 /sys/kernel/mm/ksm/run;
chmod 664 /sys/kernel/mm/ksm/run;

echo "1" > /sys/kernel/mm/ksm/run;
echo "12800" > /sys/kernel/mm/ksm/pages_to_scan;
echo "15000" > /sys/kernel/mm/ksm/sleep_millisecs;
echo