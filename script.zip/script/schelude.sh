#!/system/bin/sh
su
mount -o remount,rw -t /dev/block/mtdblock5 /system 
cp ./sdcard/symsearch.ko /system/lib/modules/symsearch.ko
cp ./lib/opperator.ko /system/lib/modules/opperator.ko
mount -o remount,ro -t /dev/block/mtdblock5 /system
insmod /system/lib/modules/symsearch.ko
insmod /system/lib/modules/opperator.ko
xargs -r param
# 1 Cooldown 500MHZ
# 2 Compatible 750MHZ
# 3 Critical 1,2GHZ
if ["$PARAM" -ge 1];then
echo "500000000" > /proc/opperator
fi
if ["$PARAM" -ge 2];then
echo "750000000" > /proc/opperator
fi
if ["$PARAM" -ge 3];then
echo "1200000000" > /proc/opperator
fi