#!/system/bin/sh
mount -o remount,rw /
mount -o remount,rw /system
insmod /system/lib/modules/bcm4329.ko
mkdir /eth0
cd /
wpa_supplicant -B -Dwext -ieth0 -c/etc/wifi/wpa_supplicant.conf
wpa_cli -p /eth0/
rm -Rf /data/misc/dhcp/*
dhcpd eth0
ntpd -p 192.168.100.1