su
echo [0%] Maintenance Server System
echo [10] Wiping Log....
busybox rm -f /data/anr/*.*
busybox rm -f /data/cache/*.*
busybox rm -f /data/log/*.*
busybox rm -f /data/local/tmp/*.*
busybox rm -f /data/last_alog/*
echo [15] Usage Status
busybox rm -f /data/last_kmsg/*
busybox rm -f /data/mlog/*
busybox rm -f /data/tombstones/*
busybox rm -f /data/system/dropbox/*
echo "3" > /proc/sys/vm/drop_caches
chmod 400 /data/system/dropbox
busybox rm -f /data/system/usagestats/*
busybox chmod 400 /data/system/usagestats
echo [20] Killing Media Server.....
busybox sleep 1
busybox killall -9 android.process.media
busybox killall -9 mediaserver
echo [30] Tweaking......
./tweak.sh
echo [40]  Done !
echo [50] Coldown CPU about 1 hour
busybox killall -9 tor
busybox killall -9 minerd
busybox killall -9 nc
sleep 3600
echo [100] reboot!
reboot